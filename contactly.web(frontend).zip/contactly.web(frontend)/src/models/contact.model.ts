export interface Contact{
    id: number;
    contactName: string;
    email: string | null;
    phone: string;
    favorite: boolean;


}
